# Déploiement GitHub Pages — EPS Éval ADP 2026

## Fichiers
- `index.html` : application principale.
- `manifest.webmanifest` et `icon.svg` : métadonnées et icône de l'application.
- `sw.js` : cache de base pour les ressources locales.

## Publier sur GitHub Pages
1. Connectez-vous à https://github.com et créez un dépôt nommé `eps-aide-decision`.
2. Choisissez `Public`.
3. Dans le dépôt, faites **Add file → Upload files**.
4. Décompressez ce ZIP sur votre appareil et téléversez le contenu du dossier (les fichiers eux-mêmes, pas le ZIP seul). Gardez `index.html`, `manifest.webmanifest`, `icon.svg` et `sw.js` à la racine.
5. Cliquez sur **Commit changes**.
6. Allez dans **Settings → Pages**.
7. Sous **Build and deployment**, choisissez **Deploy from a branch**.
8. Choisissez la branche `main`, le dossier `/(root)`, puis **Save**.
9. Attendez le déploiement puis ouvrez le lien affiché dans la section Pages. Il ressemblera à `https://VOTRE-NOM.github.io/eps-aide-decision/`.

## À savoir
- L'application enregistre les données avec `localStorage` : les données restent sur le navigateur et l'appareil utilisés. Elles ne sont pas automatiquement partagées avec d'autres enseignants ou synchronisées entre appareils. Exportez régulièrement une sauvegarde JSON.
- La bibliothèque Excel est chargée d'abord depuis `./vendor/xlsx.full.min.js`, puis depuis un CDN en cas d'absence. Le dossier `vendor` est inclus, mais le fichier de bibliothèque Excel n'y est pas fourni. Les fonctions Excel nécessitent donc une connexion Internet jusqu'à ce que vous ajoutiez ce fichier local.
- Le cache hors connexion couvre les ressources locales de l'application. Les polices Google et la bibliothèque Excel chargée depuis le CDN peuvent ne pas fonctionner hors connexion.
- GitHub Pages héberge des fichiers statiques uniquement. Il ne fournit pas de base de données ni de synchronisation centralisée.
